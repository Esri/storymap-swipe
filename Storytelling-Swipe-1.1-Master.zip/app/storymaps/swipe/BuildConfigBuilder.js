require(
	[
		"storymaps/ui/loadingIndicator/LoadingIndicator", 
		"storymaps/core/Core", 
		"storymaps/swipe/core/MainView",
		"storymaps/builder/Builder",
		"storymaps/swipe/builder/BuilderView"
	], 
	function()
	{
		// Nothing here
	}
);