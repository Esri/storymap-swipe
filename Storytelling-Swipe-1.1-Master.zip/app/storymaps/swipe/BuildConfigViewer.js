require(
	[
		"storymaps/ui/loadingIndicator/LoadingIndicator", 
		"storymaps/core/Core",
		"storymaps/swipe/core/MainView",
	], 
	function()
	{
		// Nothing here
	}
);